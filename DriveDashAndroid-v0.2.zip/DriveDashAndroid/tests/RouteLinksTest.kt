package com.drivedash.android

fun main() {
    val g = RouteLinks.parse("https://www.google.com/maps/dir/?api=1&destination=Sofia%2C%20Bulgaria")!!
    check(g.destination == "Sofia, Bulgaria" && g.google()!!.contains("dir_action=navigate") && g.waze()!!.contains("q=Sofia%2C%20Bulgaria"))
    val w = RouteLinks.parse("https://www.waze.com/ul?ll=42.7%2C23.3&navigate=yes")!!
    check(w.waze()!!.contains("ll=42.7%2C23.3") && w.google()!!.contains("destination=42.7%2C23.3"))
    val short = RouteLinks.parse("https://maps.app.goo.gl/abc")!!
    check(short.google() == short.original && short.waze() == null)
    val apple = RouteLinks.parse("https://maps.apple.com/?daddr=Plovdiv")!!
    check(apple.google()!!.contains("destination=Plovdiv") && apple.waze()!!.contains("q=Plovdiv"))
    check(RouteLinks.parse("https://maps.apple.com/?ll=42.7,23.3")!!.google() == null)
    val waypoint = RouteLinks.parse("https://www.google.com/maps/dir/?api=1&destination=Sofia&waypoints=Pernik")!!
    check(waypoint.google() == waypoint.original && waypoint.waze() == null)
    check(RouteLinks.parse("https://www.google.com/maps?query=Plovdiv&query_place_id=abc")!!.destination == null)
    for (bad in listOf("http://waze.com/ul?q=x", "https://waze.com.evil.test/ul", "https://waze.com@evil.test/", "https://www.google.com/search?q=x", "https://waze.com:8443/ul", "https://www.waze.com/ul?q=%GG")) check(RouteLinks.parse(bad) == null) { bad }
    println("RouteLinks tests passed")
}
