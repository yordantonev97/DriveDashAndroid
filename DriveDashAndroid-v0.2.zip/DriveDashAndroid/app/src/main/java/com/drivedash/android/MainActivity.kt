package com.drivedash.android

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.net.Uri
import android.provider.Settings
import android.widget.*
import android.view.Gravity
import android.service.notification.NotificationListenerService
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.Executors

class MediaAccess : NotificationListenerService()
class MainActivity : Activity() {
    private lateinit var handoff: Handoff
    private lateinit var status: TextView
    private lateinit var google: Button
    private lateinit var waze: Button
    private lateinit var clear: Button
    private lateinit var copy: Button
    private var received: Handoff.Received? = null
    private var busy = false
    private var active = false
    private var generation = 0
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val poll = object : Runnable { override fun run() { if (active) { if (handoff.config().base.isNotBlank()) fetch(); handler.postDelayed(this, 15000) } } }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handoff = Handoff(this)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(24,16,24,16) }
        fun label(value: String, size: Float) = TextView(this).apply { text = value; textSize = size; layout.addView(this) }
        fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; setOnClickListener { action() }; layout.addView(this) }
        label("DriveDash • Android 0.2",24f)
        button("1. Allow floating dashboard") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        button("2. Allow media access (optional)") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        button("Start Waze") { launch("com.waze") }
        button("Start Google Maps") { launch("com.google.android.apps.maps") }
        button("Open Spotify") { openApp("com.spotify.music") }
        button("Stop dashboard") { stopService(Intent(this, DashService::class.java)) }
        label("DriveDash Handoff",22f)
        status = label("Pair your iPhone to receive a destination.",16f)
        button("Set up pairing") { pairing() }
        button("Check for destination") { fetch() }
        google = button("Open received route in Google Maps") { received?.route?.google()?.let { launch("com.google.android.apps.maps",it) } }
        waze = button("Open received route in Waze") { received?.route?.waze()?.let { launch("com.waze",it) } }
        copy = button("Copy received map link") { received?.route?.original?.let { clipboard("Map link",it) } }
        clear = button("Clear received destination") { AlertDialog.Builder(this).setMessage("Remove this destination from your relay?").setPositiveButton("Clear") { _,_ -> fetch("DELETE") }.setNegativeButton("Cancel",null).show() }
        updateButtons()
        setContentView(ScrollView(this).apply { addView(layout) })
    }
    override fun onResume() { super.onResume(); active = true; handler.removeCallbacks(poll); handler.post(poll) }
    override fun onPause() { active = false; handler.removeCallbacks(poll); super.onPause() }
    override fun onDestroy() { generation++; executor.shutdownNow(); handler.removeCallbacksAndMessages(null); super.onDestroy() }
    private fun updateButtons() {
        google.isEnabled = received?.route?.google() != null; waze.isEnabled = received?.route?.waze() != null
        copy.isEnabled = received != null; clear.isEnabled = received != null && !busy
    }
    private fun clipboard(label: String, text: String) {
        val clip = ClipData.newPlainText(label,text)
        if (label == "Pairing key" && android.os.Build.VERSION.SDK_INT >= 24) clip.description.extras = android.os.PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE", true) }
        getSystemService(ClipboardManager::class.java).setPrimaryClip(clip)
        Toast.makeText(this,"Copied",Toast.LENGTH_SHORT).show()
    }
    private fun pairing() {
        val config = handoff.config()
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,8,24,8) }
        val base = EditText(this).apply { hint = "https://your-worker.workers.dev"; setText(config.base); inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI; isSingleLine = true }
        val token = EditText(this).apply { hint = "Pairing key"; setText(config.token); inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD; isSingleLine = true }
        layout.addView(base); layout.addView(token)
        layout.addView(Button(this).apply { text = "Generate new key"; setOnClickListener { token.setText(handoff.newToken()) } })
        layout.addView(Button(this).apply { text = "Copy key for relay & iPhone"; setOnClickListener { if(token.text.length == 43) clipboard("Pairing key",token.text.toString()) } })
        val dialog = AlertDialog.Builder(this).setTitle("Private relay pairing").setView(layout).setPositiveButton("Save",null).setNegativeButton("Cancel",null).create()
        dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            runCatching { handoff.save(base.text.toString(),token.text.toString()) }.onSuccess {
                generation++; busy = false; received = null; updateButtons(); dialog.dismiss(); fetch()
            }.onFailure { Toast.makeText(this,it.message ?: "Invalid configuration",Toast.LENGTH_LONG).show() }
        } }
        dialog.show()
    }
    private fun fetch(method: String = "GET") {
        if (busy) return
        val config = handoff.config()
        if (config.base.isBlank()) { status.text = "Set up pairing first."; return }
        busy = true; updateButtons()
        val current = generation
        executor.execute {
            val result = runCatching { handoff.request(config,method) }
            handler.post {
                if (isDestroyed || current != generation) return@post
                busy = false
                result.onSuccess {
                    received = it
                    status.text = if(it == null) "No pending destination." else "Received: ${it.route.destination ?: it.route.provider.name + " map link"}\n${DateFormat.getDateTimeInstance().format(Date(it.sentAt * 1000))}"
                }.onFailure { received = null; status.text = "Handoff unavailable: ${it.message ?: "Connection failed"}" }
                updateButtons()
            }
        }
    }
    private fun launch(pkg: String, link: String? = null) {
        val i = if (link == null) packageManager.getLaunchIntentForPackage(pkg) else Intent(Intent.ACTION_VIEW, Uri.parse(link)).setPackage(pkg)
        if(i == null) { Toast.makeText(this,"Install the app first",Toast.LENGTH_SHORT).show(); return }
        if (!Settings.canDrawOverlays(this) && link == null) { Toast.makeText(this,"Allow overlay first",Toast.LENGTH_SHORT).show(); return }
        if(Settings.canDrawOverlays(this)) startForegroundService(Intent(this,DashService::class.java))
        try { startActivity(i) } catch(e: android.content.ActivityNotFoundException) { Toast.makeText(this,"Map app could not open this link. Copy the link to try manually.",Toast.LENGTH_LONG).show() }
    }
    private fun openApp(pkg: String) { val i = packageManager.getLaunchIntentForPackage(pkg); if(i != null) startActivity(i) else Toast.makeText(this,"Install the app first",Toast.LENGTH_SHORT).show() }
}
