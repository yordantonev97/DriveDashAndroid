package com.drivedash.android
import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.*
import android.os.*
import android.view.*
import android.widget.*
import android.provider.Settings
import kotlin.math.abs

class DashService : Service() {
 private lateinit var wm: WindowManager
 private var panel: LinearLayout? = null
 private lateinit var params: WindowManager.LayoutParams
 private lateinit var song: TextView
 private lateinit var play: Button
 private lateinit var controls: LinearLayout
 private val handler = Handler(Looper.getMainLooper())
 private var expanded = true
 private fun dp(n:Int) = (n * resources.displayMetrics.density).toInt()
 private fun session(): MediaController? = try {
  getSystemService(MediaSessionManager::class.java).getActiveSessions(ComponentName(this, MediaAccess::class.java)).firstOrNull { it.packageName == "com.spotify.music" }
 } catch(e: SecurityException) { null }
 private val tick = object : Runnable { override fun run() {
  val c = session(); val m = c?.metadata
  song.text = if(c == null) "Spotify • enable media access / play music" else listOfNotNull(m?.getString(MediaMetadata.METADATA_KEY_TITLE),m?.getString(MediaMetadata.METADATA_KEY_ARTIST)).joinToString("\n").ifBlank { "Spotify" }
  play.text = if(c?.playbackState?.state == PlaybackState.STATE_PLAYING) "Ⅱ" else "▶"
  handler.postDelayed(this,1000)
 } }
 override fun onBind(intent: Intent?) = null
 override fun onStartCommand(intent: Intent?, flags:Int, startId:Int):Int {
  val nm = getSystemService(NotificationManager::class.java)
  nm.createNotificationChannel(NotificationChannel("dash","DriveDash",NotificationManager.IMPORTANCE_LOW))
  val stop = PendingIntent.getService(this,1,Intent(this,DashService::class.java).setAction("stop"),PendingIntent.FLAG_IMMUTABLE)
  startForeground(1,Notification.Builder(this,"dash").setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("DriveDash dashboard").addAction(Notification.Action.Builder(null,"Stop",stop).build()).build())
  if(intent?.action == "stop" || !Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
  if(panel == null) { try { showPanel() } catch(e:Exception) { stopSelf() } }
  return START_NOT_STICKY
 }
 private fun showPanel() {
  wm = getSystemService(WindowManager::class.java)
  params = WindowManager.LayoutParams(dp(250),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.LEFT; x=dp(12); y=dp(70) }
  val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(8),dp(4),dp(8),dp(8)); background=GradientDrawable().apply { setColor(0xEE17252A.toInt()); cornerRadius=dp(16).toFloat() } }
  val header = TextView(this).apply { text="DriveDash   •   drag / tap"; textSize=16f; setTextColor(Color.WHITE); setPadding(dp(8),dp(12),dp(8),dp(12)) }
  root.addView(header)
  controls = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
  song = TextView(this).apply { textSize=15f; setTextColor(Color.WHITE); maxLines=3; setPadding(dp(8),0,dp(8),dp(8)) }; controls.addView(song)
  val row = LinearLayout(this)
  fun key(label:String, action:()->Unit):Button = Button(this).apply { text=label; contentDescription=when(label){"⏮"->"Previous";"⏭"->"Next";else->"Play or pause"}; setOnClickListener { action() }; row.addView(this,LinearLayout.LayoutParams(0,dp(54),1f)) }
  key("⏮") { session()?.transportControls?.skipToPrevious() }; play=key("▶") { session()?.let { if(it.playbackState?.state==PlaybackState.STATE_PLAYING) it.transportControls.pause() else it.transportControls.play() } }; key("⏭") { session()?.transportControls?.skipToNext() }
  controls.addView(row)
  controls.addView(Button(this).apply { text = "Received route"; setOnClickListener {
   startActivity(Intent(this@DashService,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
  } }); root.addView(controls)
  var sx=0f; var sy=0f; var px=0; var py=0
  header.setOnTouchListener { _,e -> when(e.actionMasked) {
   MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; px=params.x; py=params.y; true }
   MotionEvent.ACTION_MOVE -> { params.x=(px+(e.rawX-sx).toInt()).coerceIn(0,(resources.displayMetrics.widthPixels-root.width).coerceAtLeast(0)); params.y=(py+(e.rawY-sy).toInt()).coerceIn(0,(resources.displayMetrics.heightPixels-root.height).coerceAtLeast(0)); wm.updateViewLayout(root,params); true }
   MotionEvent.ACTION_UP -> { if(abs(e.rawX-sx)<dp(8)&&abs(e.rawY-sy)<dp(8)) { expanded=!expanded; controls.visibility=if(expanded) View.VISIBLE else View.GONE; params.width=dp(if(expanded)250 else 180); wm.updateViewLayout(root,params) }; true }
   else -> false
  } }
  wm.addView(root,params); panel=root; handler.post(tick)
 }
 override fun onDestroy() { handler.removeCallbacksAndMessages(null); panel?.let { runCatching { wm.removeView(it) } }; panel=null; super.onDestroy() }
}
