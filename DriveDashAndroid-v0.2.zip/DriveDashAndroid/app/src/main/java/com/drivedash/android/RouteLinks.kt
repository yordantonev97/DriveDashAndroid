package com.drivedash.android

import java.net.URI
import java.net.URLDecoder
import java.net.URLEncoder

/** Only map-provider HTTPS links are accepted; opaque short links stay with their provider. */
object RouteLinks {
    enum class Provider { GOOGLE, WAZE, APPLE }
    data class Route(val original: String, val provider: Provider, val destination: String?) {
        fun google(): String? = destination?.let { "https://www.google.com/maps/dir/?api=1&destination=${enc(it)}&travelmode=driving&dir_action=navigate" }
            ?: original.takeIf { provider == Provider.GOOGLE }
        fun waze(): String? = destination?.let {
            val key = if (it.matches(Regex("-?\\d+(\\.\\d+)?\\s*,\\s*-?\\d+(\\.\\d+)?"))) "ll" else "q"
            "https://www.waze.com/ul?$key=${enc(it)}&navigate=yes"
        } ?: original.takeIf { provider == Provider.WAZE }
    }
    private fun enc(value: String) = URLEncoder.encode(value, "UTF-8").replace("+", "%20")
    private fun dec(value: String) = URLDecoder.decode(value, "UTF-8")
    fun parse(value: String): Route? = runCatching {
        val raw = value.trim()
        require(raw.length in 1..4096)
        val u = URI(raw)
        require(u.scheme.equals("https", true) && u.userInfo == null && u.port in listOf(-1, 443))
        val host = u.host?.lowercase() ?: return null
        val path = u.path ?: ""
        val provider = when {
            host == "maps.app.goo.gl" || host == "maps.google.com" ||
                (host in setOf("www.google.com", "google.com", "goo.gl") && (path == "/maps" || path.startsWith("/maps/"))) -> Provider.GOOGLE
            host in setOf("waze.com", "www.waze.com") -> Provider.WAZE
            host == "maps.apple.com" -> Provider.APPLE
            else -> return null
        }
        val q = u.rawQuery.orEmpty().split('&').mapNotNull {
            val i = it.indexOf('='); if (i < 0) null else dec(it.substring(0,i)) to dec(it.substring(i+1))
        }.toMap()
        fun first(vararg keys: String) = keys.firstNotNullOfOrNull { q[it]?.trim()?.takeIf(String::isNotBlank) }
        val dest = when(provider) {
            Provider.GOOGLE -> first("destination", "daddr") ?: if (q["query_place_id"] == null) first("query", "q") else null
            Provider.WAZE -> first("ll", "q").takeIf { q["place"] == null && q["venue_id"] == null && q["favorite"] == null }
            Provider.APPLE -> first("daddr", "destination", "address", "q") // ll alone may simply be map center
        }?.takeIf { it.length <= 512 && it.none(Char::isISOControl) }
        // Keep original Google links when they contain explicit place IDs or waypoints.
        val safeDest = dest.takeUnless { provider == Provider.GOOGLE && (q.containsKey("destination_place_id") || q.containsKey("waypoints") || q.containsKey("waypoint_place_ids")) }
        Route(raw, provider, safeDest)
    }.getOrNull()
}
