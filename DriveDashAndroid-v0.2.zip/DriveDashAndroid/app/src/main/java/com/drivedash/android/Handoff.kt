package com.drivedash.android

import android.content.Context
import android.util.Base64
import org.json.JSONObject
import java.net.URI
import java.net.URL
import java.security.SecureRandom
import javax.net.ssl.HttpsURLConnection

class Handoff(context: Context) {
    private val prefs = context.getSharedPreferences("handoff", Context.MODE_PRIVATE)
    data class Config(val base: String, val token: String)
    data class Received(val route: RouteLinks.Route, val sentAt: Long)
    fun config() = Config(prefs.getString("base", "").orEmpty(), prefs.getString("token", "").orEmpty())
    fun newToken(): String = ByteArray(32).also { SecureRandom().nextBytes(it) }.let {
        Base64.encodeToString(it, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
    }
    fun save(base: String, token: String): Config {
        val trimmed = base.trim().trimEnd('/')
        val uri = URI(trimmed)
        require(uri.scheme == "https" && uri.host != null && uri.userInfo == null && uri.port in listOf(-1,443) && uri.rawQuery == null && uri.rawFragment == null && uri.path.isNullOrEmpty()) { "Use the HTTPS Worker address, without a path." }
        require(token.matches(Regex("[A-Za-z0-9_-]{43}"))) { "Use a 43-character pairing key." }
        prefs.edit().putString("base", trimmed).putString("token", token).apply()
        return Config(trimmed, token)
    }
    fun request(config: Config, method: String): Received? {
        require(config.base.isNotBlank() && config.token.isNotBlank()) { "Set up pairing first." }
        val connection = URL(config.base + "/v1/destination").openConnection() as HttpsURLConnection
        try {
            connection.instanceFollowRedirects = false
            connection.connectTimeout = 8000; connection.readTimeout = 8000
            connection.requestMethod = method
            connection.setRequestProperty("Authorization", "Bearer ${config.token}")
            connection.setRequestProperty("Accept", "application/json")
            when (val status = connection.responseCode) {
                204 -> return null
                401 -> error("Pairing key does not match the relay.")
                200 -> {
                    val bytes = connection.inputStream.use { input ->
                        val buffer = ByteArray(8193); var length = 0
                        while (length < buffer.size) { val n = input.read(buffer, length, buffer.size-length); if(n < 0) break; length += n }
                        require(length < buffer.size) { "Response too large." }; buffer.copyOf(length)
                    }
                    val data = JSONObject(bytes.toString(Charsets.UTF_8))
                    val route = RouteLinks.parse(data.getString("url")) ?: error("Unsupported destination link.")
                    return Received(route, data.getLong("sentAt"))
                }
                else -> error("Relay returned HTTP $status.")
            }
        } finally { connection.disconnect() }
    }
}
