# Private iPhone → Android destination relay

One relay for one personal pair of devices. Cloudflare Workers and D1 have free-plan allowances; stay on the free plan and review the provider's limits. No API key from Google Maps or Waze is required. This is not an end-to-end encrypted service. Do not deploy a public/shared instance using one key for many people.

## 1. Create the relay

On Windows, install Node.js LTS (22 or later) and open PowerShell in the project's `relay` folder. Use your own Cloudflare account. These are one-time commands; they create cloud resources in that account. Do not paste private keys into GitHub or ChatGPT.

```powershell
npx wrangler@4 login
npx wrangler@4 d1 create drivedash-handoff
Copy-Item wrangler.toml.example wrangler.toml
```

Edit `wrangler.toml` and replace `REPLACE_WITH_DATABASE_ID` with the database UUID from the previous command. You may change the Worker name if needed. `wrangler.toml` is gitignored. The secret is not in this file.

```powershell
npx wrangler@4 d1 execute drivedash-handoff --remote --file=./schema.sql
npx wrangler@4 deploy
```

Copy the deployed HTTPS URL (no path, e.g. `https://drivedash-handoff.YOUR-SUBDOMAIN.workers.dev`). The service refuses all requests until the secret is set. Generate a random key on your own machine:

```powershell
node -e "console.log(require('node:crypto').randomBytes(32).toString('base64url'))"
npx wrangler@4 secret put PAIRING_TOKEN
```

Paste the generated key at the hidden prompt. Alternatively generate the key using DriveDash's pairing dialog and enter the exact same key into Wrangler. Never store it in the repository, a URL query parameter or a public Shortcut. Keep a private copy until both devices are paired. In Cloudflare, leave observability/request logging off for this relay and review the settings for your account. The code does not log addresses or keys.

## 2. Motorola

Install DriveDash APK. Open Set up pairing, enter the Worker HTTPS address (no trailing path) and the key, then Save. Check for destination should show No pending destination, not a 401 or connection error. No notification permissions are needed for Handoff itself. Both devices require internet.

## 3. iPhone — manually create the Shortcut

The native iOS DriveDash prototype is not needed. In Apple's Shortcuts app:

1. Create a new shortcut named `Send to DriveDash`. In Details enable Show in Share Sheet. Set input types to URLs and Text.
2. Add `Get URLs from Input`, taking Shortcut Input. Add `Get Item from List` (First Item). If no URL was supplied, stop; the sender must share a map link rather than plain text. Optionally inspect the URL before sending.
3. Add the Worker endpoint as a URL action: `https://YOUR-WORKER.workers.dev/v1/destination`. Add `Get Contents of URL`, using the endpoint as input. Expand the action's options and set Method to POST.
4. Add header `Authorization` with value `Bearer YOUR_PRIVATE_PAIRING_KEY` (one space after Bearer). Set Request Body to JSON, add Text field `url`, and insert the **First Item** magic variable from step 2, not the endpoint URL. The action should send JSON of the form `{"url":"https://..."}`. Shortcuts sets the JSON content type when JSON body is selected; if necessary add header `Content-Type: application/json`.
5. Optionally add `Get Dictionary Value` for `ok` from the response, then If `ok` is true, show notification `Destination sent to DriveDash`; otherwise show an error. Do not show success unconditionally. Run once and grant the Shortcut permission to contact your own Worker.
6. In Google Maps or Waze choose a destination and use its Share option; select Send to DriveDash. Apple Maps explicit address links may also work. Open DriveDash on the Motorola and check the inbox. Check the actual point/route before driving.

Shortcut UI labels may differ by iOS version/language. No installable `.shortcut` file is supplied; Apple Shortcuts must be configured on the iPhone. Do not publicly share your configured shortcut because it contains the pairing key. No Google or Waze sign-in credentials are used by the relay.

## 4. Expected behavior and troubleshooting

- 401: verify the key is identical in Wrangler, Android, and iPhone. Do not send the key to anyone.
- 204 from GET / No pending destination: empty inbox or older than 12 hours. Send again.
- 400 from POST: use a supported HTTPS map share link (Google, Waze, or Apple Maps; certain regional or obscure links may be rejected). Shortcuts must send a `url` text field.
- 503: check Worker binding `DB`, applied schema and Cloudflare quotas.
- Wrong/no destination: opaque share links open only in the source provider; opaque Apple links and map-center-only links cannot be converted. Use an explicit address or Google/Waze share link. If launch fails, copy the link and open in the appropriate app manually.
- Refresh is performed when DriveDash is visible; it does not interrupt Waze or Google Maps. Tap the floating panel's Received route button to open DriveDash. Clear the inbox only after confirming no newer link was sent; clearing removes the latest server entry.
- For personal use, optional overlay/media permission can be revoked at any time. To stop Handoff, delete the Worker/DB in your Cloudflare account, clear app data, and delete the Shortcut. Cloudflare backups/time-travel may retain past rows under the provider's retention policy.

## Local verification

Run `node --test test/relay.test.mjs` here with Node 22+. Uses in-memory SQLite to exercise the actual SQL and simulated D1 bindings. Production deployment, live Shortcuts behavior and Android APK/device testing remain to be done.

Official references:
- https://developers.cloudflare.com/d1/get-started/
- https://developers.cloudflare.com/workers/configuration/secrets/
- https://developers.cloudflare.com/d1/platform/pricing/
- https://developers.google.com/maps/documentation/urls/get-started
- https://developers.google.com/waze/deeplinks/
