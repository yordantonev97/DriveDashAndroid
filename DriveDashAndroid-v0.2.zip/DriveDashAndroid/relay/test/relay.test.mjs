import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import worker, {allowedLink} from '../src/index.mjs';
const token = 'a'.repeat(43);
function fixture() {
  const db = new DatabaseSync(':memory:');
  db.exec(readFileSync(new URL('../schema.sql',import.meta.url),'utf8'));
  const env = {PAIRING_TOKEN:token, DB:{prepare(sql) { const stmt=db.prepare(sql); function binding(args) { return {run:async()=>stmt.run(...args),first:async()=>stmt.get(...args) ?? null}; } return {...binding([]),bind:(...args)=>binding(args)}; }}};
  const req = (method, url, key=token) => worker.fetch(new Request('https://test.invalid/v1/destination',{method,headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},...(url===undefined ? {}:{body:JSON.stringify({url})})}),env);
  return {db,env,req};
}
test('authenticated send, retrieve, replace, delete',async()=>{
  const {req}=fixture();
  assert.equal((await req('GET')).status,204);
  const a='https://maps.app.goo.gl/abc';
  const b='https://www.waze.com/ul?ll=42.7%2C23.3';
  assert.equal((await req('POST',a)).status,200);
  assert.equal((await (await req('GET')).json()).url,a);
  assert.equal((await req('POST',b)).status,200);
  assert.equal((await (await req('GET')).json()).url,b);
  assert.equal((await req('DELETE')).status,204);
  assert.equal((await req('GET')).status,204);
});
test('unauthenticated and unsupported links rejected',async()=>{
  const {req}=fixture();
  assert.equal((await req('POST','https://maps.app.goo.gl/abc','b'.repeat(43))).status,401);
  for(const u of ['http://www.waze.com/ul','https://maps.app.goo.gl.evil.invalid/','https://waze.com@evil.invalid/','https://www.google.com/search?q=foo','https://waze.com:8443/ul','https://waze.com/ul?q=a b']) {
    assert.equal(allowedLink(u),false,u); assert.equal((await req('POST',u)).status,400);
  }
  assert.equal((await req('GET')).status,204);
});
test('expired data not delivered and scheduled cleanup deletes it',async()=>{
  const {db,env,req}=fixture();
  await req('POST','https://maps.apple.com/?daddr=Sofia');
  db.exec('UPDATE inbox SET expires_at=0');
  assert.equal((await req('GET')).status,204);
  await worker.scheduled(null,env);
  assert.equal(db.prepare('SELECT count(*) AS n FROM inbox').get().n,0);
});
test('oversized and malformed body rejected',async()=>{
  const {env,req}=fixture();
  assert.equal((await req('POST','https://maps.app.goo.gl/'+'a'.repeat(9000))).status,400);
  const res=await worker.fetch(new Request('https://test.invalid/v1/destination',{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:'{bad'}),env);
  assert.equal(res.status,400);
});
