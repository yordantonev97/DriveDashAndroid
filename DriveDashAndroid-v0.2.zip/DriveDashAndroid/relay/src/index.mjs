const TTL = 12 * 60 * 60;
const MAX = 8192;
function response(data, status = 200) {
  return new Response(data === null ? null : JSON.stringify(data), {status, headers:{'Cache-Control':'no-store','Content-Type':'application/json; charset=utf-8','X-Content-Type-Options':'nosniff'}});
}
export function allowedLink(raw) {
  if (typeof raw !== 'string' || raw.length === 0 || raw.length > 4096 || /[\u0000-\u0020\u007f]/.test(raw)) return false;
  let u; try { u = new URL(raw); } catch { return false; }
  if(u.protocol !== 'https:' || u.username || u.password || u.port) return false;
  return ['maps.app.goo.gl','maps.google.com','waze.com','www.waze.com','maps.apple.com'].includes(u.hostname) ||
    (['www.google.com','google.com','goo.gl'].includes(u.hostname) && (u.pathname === '/maps' || u.pathname.startsWith('/maps/')));
}
async function authenticated(request, secret) {
  const auth = request.headers.get('Authorization') || '';
  if (!/^[A-Za-z0-9_-]{43}$/.test(secret || '') || !/^Bearer [A-Za-z0-9_-]{43}$/.test(auth)) return false;
  const enc = new TextEncoder();
  const [a,b] = await Promise.all([crypto.subtle.digest('SHA-256',enc.encode(auth.slice(7))),crypto.subtle.digest('SHA-256',enc.encode(secret))]);
  const x = new Uint8Array(a), y = new Uint8Array(b); let diff = 0;
  for (let i = 0; i < x.length; i++) diff |= x[i] ^ y[i];
  return diff === 0;
}
async function body(request) {
  if (!request.body) throw new Error('missing body');
  const reader = request.body.getReader(); let length = 0; const parts = [];
  try {
    while (true) { const {value,done} = await reader.read(); if(done) break; length += value.length; if(length > MAX) { await reader.cancel(); throw new Error('body too large'); } parts.push(value); }
  } finally { reader.releaseLock(); }
  const all = new Uint8Array(length); let offset = 0;
  for (const part of parts) { all.set(part,offset); offset += part.length; }
  return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(all));
}
export default {
  async fetch(request, env) {
    if (new URL(request.url).pathname !== '/v1/destination') return response({error:'not found'},404);
    if (!await authenticated(request,env.PAIRING_TOKEN)) return response({error:'unauthorized'},401);
    const now = Math.floor(Date.now()/1000);
    try {
      if (request.method === 'POST') {
        if (!/^application\/json(?:\s*;|$)/i.test(request.headers.get('Content-Type') || '')) return response({error:'JSON required'},415);
        let data; try { data = await body(request); } catch { return response({error:'invalid or oversized JSON'},400); }
        const url = typeof data?.url === 'string' ? data.url.trim() : '';
        if (!allowedLink(url)) return response({error:'unsupported maps link'},400);
        await env.DB.prepare('INSERT INTO inbox (id,url,sent_at,expires_at) VALUES (1,?,?,?) ON CONFLICT(id) DO UPDATE SET url=excluded.url,sent_at=excluded.sent_at,expires_at=excluded.expires_at').bind(url,now,now+TTL).run();
        return response({ok:true,sentAt:now});
      }
      if (request.method === 'GET') {
        const row = await env.DB.prepare('SELECT url,sent_at FROM inbox WHERE id=1 AND expires_at > ?').bind(now).first();
        return row ? response({url:row.url,sentAt:row.sent_at}) : response(null,204);
      }
      if (request.method === 'DELETE') { await env.DB.prepare('DELETE FROM inbox WHERE id=1').run(); return response(null,204); }
      return response({error:'method not allowed'},405);
    } catch { return response({error:'relay unavailable'},503); }
  },
  async scheduled(_event, env) { await env.DB.prepare('DELETE FROM inbox WHERE expires_at <= ?').bind(Math.floor(Date.now()/1000)).run(); }
};
